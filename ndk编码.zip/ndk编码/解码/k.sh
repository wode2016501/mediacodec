gcc 1.0.cpp -lmediandk -lsdlapi -lc++ -llog "$@" 


gcc *.c  -I/storage/emulated/0/lib/ffmpeg/usr/include  /storage/emulated/0/lib/ffmpeg/usr/lib/*.a  -lm -latomic -landroid -lz -lm -lOpenSLES -ldl -llog -landroid -lGLESv1_CM -lGLESv2 -lvulkan -lOpenCL  
